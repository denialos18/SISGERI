<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* pages/admin/inventory/upload_form.html.twig */
class __TwigTemplate_bb981156ec85c8aca0fc66c804b1f927 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 33
        yield "
";
        // line 34
        $macros["fields"] = $this->macros["fields"] = $this->loadTemplate("components/form/fields_macros.html.twig", "pages/admin/inventory/upload_form.html.twig", 34)->unwrap();
        // line 35
        yield "
<form method='POST' enctype='multipart/form-data'>
    <h2>
        ";
        // line 38
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("Import inventory files"), "html", null, true);
        yield "
    </h2>
    <div class=\"alert alert-info\" role=\"alert\">
        <p>
            ";
        // line 42
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::sprintf(__("You can use this menu to upload one or several inventory files. Files must have a known extension (%1\$s).
"), Twig\Extension\CoreExtension::join(($context["inventory_extensions"] ?? null), ", ")), "html", null, true);
        yield "<br>
            ";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(__("It is also possible to upload a compressed archive directly with a collection of inventory files."), "html", null, true);
        yield "
        </p>
    </div>
    ";
        // line 46
        yield CoreExtension::callMacro($macros["fields"], "macro_fileField", ["inventory_files[]", "", "", ["is_horizontal" => true, "simple" => true, "no_label" => true, "multiple" => true, "required" => true]], 46, $context, $this->getSourceContext());
        // line 57
        yield "

    <button class=\"btn btn-primary me-2\" type=\"submit\"
            name=\"upload_inventory\" value=\"1\">
        <i class=\"ti ti-upload\"></i>
        <span>";
        // line 62
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(_x("button", "Upload"), "html", null, true);
        yield "</span>
    </button>

    <input type=\"hidden\" name=\"_glpi_csrf_token\" value=\"";
        // line 65
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Session::getNewCSRFToken(), "html", null, true);
        yield "\" />
</form>
";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "pages/admin/inventory/upload_form.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  81 => 65,  75 => 62,  68 => 57,  66 => 46,  60 => 43,  55 => 42,  48 => 38,  43 => 35,  41 => 34,  38 => 33,);
    }

    public function getSourceContext()
    {
        return new Source("", "pages/admin/inventory/upload_form.html.twig", "/home1/reidae97/sysi.reidaeconomia.com/templates/pages/admin/inventory/upload_form.html.twig");
    }
}
