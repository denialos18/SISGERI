<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @databaseinventory/credential.html.twig */
class __TwigTemplate_5f00f2d3f20884fd6f2af11265897068 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'more_fields' => [$this, 'block_more_fields'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 29
        return "generic_show_form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 30
        $macros["fields"] = $this->macros["fields"] = $this->loadTemplate("components/form/fields_macros.html.twig", "@databaseinventory/credential.html.twig", 30)->unwrap();
        // line 29
        $this->parent = $this->loadTemplate("generic_show_form.html.twig", "@databaseinventory/credential.html.twig", 29);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 32
    public function block_more_fields($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 33
        yield "
    ";
        // line 34
        yield CoreExtension::callMacro($macros["fields"], "macro_dropdownNumberField", ["port", (($__internal_compile_0 = CoreExtension::getAttribute($this->env, $this->source,         // line 36
($context["item"] ?? null), "fields", [], "any", false, false, false, 36)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["port"] ?? null) : null), __("Port", "databaseinventory"), ["min" => 0, "max" => 99999, "step" => 1]], 34, $context, $this->getSourceContext());
        // line 39
        yield "

    ";
        // line 41
        yield CoreExtension::callMacro($macros["fields"], "macro_textField", ["login", (($__internal_compile_1 = CoreExtension::getAttribute($this->env, $this->source,         // line 43
($context["item"] ?? null), "fields", [], "any", false, false, false, 43)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["login"] ?? null) : null), __("Login", "databaseinventory")], 41, $context, $this->getSourceContext());
        // line 46
        yield "

   ";
        // line 48
        yield CoreExtension::callMacro($macros["fields"], "macro_passwordField", ["password", (($__internal_compile_2 = CoreExtension::getAttribute($this->env, $this->source,         // line 50
($context["item"] ?? null), "fields", [], "any", false, false, false, 50)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["password"] ?? null) : null), __("Password", "databaseinventory"), ["clearable" => false, "is_disclosable" => true]], 48, $context, $this->getSourceContext());
        // line 54
        yield "
   ";
        // line 55
        yield CoreExtension::callMacro($macros["fields"], "macro_textField", ["socket", (($__internal_compile_3 = CoreExtension::getAttribute($this->env, $this->source,         // line 57
($context["item"] ?? null), "fields", [], "any", false, false, false, 57)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["socket"] ?? null) : null), __("Socket", "databaseinventory")], 55, $context, $this->getSourceContext());
        // line 60
        yield "

";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "@databaseinventory/credential.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  80 => 60,  78 => 57,  77 => 55,  74 => 54,  72 => 50,  71 => 48,  67 => 46,  65 => 43,  64 => 41,  60 => 39,  58 => 36,  57 => 34,  54 => 33,  50 => 32,  45 => 29,  43 => 30,  36 => 29,);
    }

    public function getSourceContext()
    {
        return new Source("", "@databaseinventory/credential.html.twig", "/home1/reidae97/sysi.reidaeconomia.com/marketplace/databaseinventory/templates/credential.html.twig");
    }
}
