<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @geninventorynumber/config.html.twig */
class __TwigTemplate_d94a90db39d400c180058b45289414df extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_fields' => [$this, 'block_form_fields'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 29
        return "generic_show_form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 30
        $macros["fields"] = $this->macros["fields"] = $this->loadTemplate("components/form/fields_macros.html.twig", "@geninventorynumber/config.html.twig", 30)->unwrap();
        // line 29
        $this->parent = $this->loadTemplate("generic_show_form.html.twig", "@geninventorynumber/config.html.twig", 29);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 32
    public function block_form_fields($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 33
        yield "
    ";
        // line 34
        yield CoreExtension::callMacro($macros["fields"], "macro_readOnlyField", ["name", (($__internal_compile_0 = CoreExtension::getAttribute($this->env, $this->source,         // line 36
($context["item"] ?? null), "fields", [], "any", false, false, false, 36)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["name"] ?? null) : null), __("Field")], 34, $context, $this->getSourceContext());
        // line 38
        yield "
    ";
        // line 39
        yield CoreExtension::callMacro($macros["fields"], "macro_nullField", [], 39, $context, $this->getSourceContext());
        yield "

    ";
        // line 41
        yield CoreExtension::callMacro($macros["fields"], "macro_dropdownYesNo", ["is_active", (($__internal_compile_1 = CoreExtension::getAttribute($this->env, $this->source,         // line 43
($context["item"] ?? null), "fields", [], "any", false, false, false, 43)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["is_active"] ?? null) : null), __("Active")], 41, $context, $this->getSourceContext());
        // line 45
        yield "
    ";
        // line 46
        yield CoreExtension::callMacro($macros["fields"], "macro_nullField", [], 46, $context, $this->getSourceContext());
        yield "

    ";
        // line 48
        yield CoreExtension::callMacro($macros["fields"], "macro_numberField", ["index", (($__internal_compile_2 = CoreExtension::getAttribute($this->env, $this->source,         // line 50
($context["item"] ?? null), "fields", [], "any", false, false, false, 50)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["index"] ?? null) : null), __("Global index position", "geninventorynumber")], 48, $context, $this->getSourceContext());
        // line 52
        yield "
    ";
        // line 53
        yield CoreExtension::callMacro($macros["fields"], "macro_nullField", [], 53, $context, $this->getSourceContext());
        yield "

    ";
        // line 55
        yield CoreExtension::callMacro($macros["fields"], "macro_dropdownArrayField", ["auto_reset_method", (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 57
($context["item"] ?? null), "fields", [], "any", false, true, false, 57), "auto_reset_method", [], "array", true, true, false, 57) &&  !(null === (($__internal_compile_3 = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "fields", [], "any", false, true, false, 57)) && is_array($__internal_compile_3) || $__internal_compile_3 instanceof ArrayAccess ? ($__internal_compile_3["auto_reset_method"] ?? null) : null)))) ? ((($__internal_compile_4 = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "fields", [], "any", false, true, false, 57)) && is_array($__internal_compile_4) || $__internal_compile_4 instanceof ArrayAccess ? ($__internal_compile_4["auto_reset_method"] ?? null) : null)) : (0)),         // line 58
($context["auto_reset_methods"] ?? null), __("Index auto-reset method", "geninventorynumber")], 55, $context, $this->getSourceContext());
        // line 60
        yield "
    ";
        // line 61
        yield CoreExtension::callMacro($macros["fields"], "macro_nullField", [], 61, $context, $this->getSourceContext());
        yield "

    ";
        // line 63
        yield CoreExtension::callMacro($macros["fields"], "macro_textareaField", ["comment", (($__internal_compile_5 = CoreExtension::getAttribute($this->env, $this->source,         // line 65
($context["item"] ?? null), "fields", [], "any", false, false, false, 65)) && is_array($__internal_compile_5) || $__internal_compile_5 instanceof ArrayAccess ? ($__internal_compile_5["comment"] ?? null) : null), __("Comments")], 63, $context, $this->getSourceContext());
        // line 67
        yield "
    ";
        // line 68
        yield CoreExtension::callMacro($macros["fields"], "macro_nullField", [], 68, $context, $this->getSourceContext());
        yield "

";
        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "@geninventorynumber/config.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  108 => 68,  105 => 67,  103 => 65,  102 => 63,  97 => 61,  94 => 60,  92 => 58,  91 => 57,  90 => 55,  85 => 53,  82 => 52,  80 => 50,  79 => 48,  74 => 46,  71 => 45,  69 => 43,  68 => 41,  63 => 39,  60 => 38,  58 => 36,  57 => 34,  54 => 33,  50 => 32,  45 => 29,  43 => 30,  36 => 29,);
    }

    public function getSourceContext()
    {
        return new Source("", "@geninventorynumber/config.html.twig", "/home1/reidae97/sysi.reidaeconomia.com/marketplace/geninventorynumber/templates/config.html.twig");
    }
}
