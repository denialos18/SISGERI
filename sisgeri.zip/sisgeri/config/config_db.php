<?php
class DB extends DBmysql {
   public $dbhost = 'localhost';
   public $dbuser = 'reidae97_root';
   public $dbpassword = '%23%23Z8fsdfg3';
   public $dbdefault = 'reidae97_sysi';
   public $use_utf8mb4 = true;
   public $allow_myisam = false;
   public $allow_datetime = false;
   public $allow_signed_keys = false;
}
